﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ContactDataInterfaces
{
    public interface INotes : IDataObject
    {
        IParent Parent { get; set; }
        IParentType ParentType { get; set; }
        string NoteTitle { get; set; }
        string Note { get; set; }
    }
}
