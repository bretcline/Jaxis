﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ContactDataInterfaces
{
    public interface ICompany : IDataObject
    {
        string CompanyName { get; set; }
        IRelationshipType RelationshipType { get; set; }
        IContact PrimaryContact { get; set; }
        IAddress PrimaryAddress { get; set; }
        IPhoneNumber PrimaryPhoneNumber { get; set; }
        IList<IAddress> AddressList { get; set; }
        IList<IPhoneNumber> PhoneNumberList { get; set; }
    }
}
