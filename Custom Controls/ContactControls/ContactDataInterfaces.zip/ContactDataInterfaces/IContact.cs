﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ContactDataInterfaces
{
    public interface IContact : IDataObject
    {
        IContactType ContactType { get; set; }
        string FirstName { get; set; }
        string MiddleName { get; set; }
        string LastName { get; set; }
        IAddress PrimaryAddress { get; set; }
        IList<IAddress> AddressList { get; set; }
        ICompany Company { get; set; }
        IPhoneNumber PrimaryPhoneNumber { get; set; }
        IList<IPhoneNumber> PhoneNumberList { get; set; }
    }
}
