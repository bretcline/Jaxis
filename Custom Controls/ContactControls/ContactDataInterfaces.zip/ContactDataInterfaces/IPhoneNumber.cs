﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ContactDataInterfaces
{
    public interface IPhoneNumber : IDataObject
    {
        IPhoneNumberType PhoneNumberType { get; set; }
        string AreaCode { get; set; }
        string Prefix { get; set; }
        string Suffix { get; set; }
        string Extension { get; set; }
    }
}
