﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ContactDataInterfaces
{
    public interface IDataObject
    {

    }

    public interface IDataManager
    {
        T Create<T>( ) where T : IDataObject, new( );
        T Get<T>( Guid _ElementID ) where T : IDataObject, new( );
        bool Save<T>( T _Element ) where T : IDataObject;
        bool Delete<T>( Guid _ElementID ) where T : IDataObject;
    }
}
