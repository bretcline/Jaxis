﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ContactDataInterfaces
{
    public interface IContactType : IDataObject
    {
        string Name { get; set; }
        string Description { get; set; }
    }
}
