﻿namespace ISO_Demo {


    partial class dsTags
    {
    }
}
